<!-- _coverpage.md -->

<!-- ![logo](_media/icon.svg) -->

# SOGamers 

<!-- > A magical documentation site generator.

- Simple and lightweight
- No statically built html files
- Multiple themes -->

[Profile](http://bit.ly/SOGamersProfile)
[Discord](https://discord.gg/sogamers)
[Telegram](http://bit.ly/SOGamersChannels)
